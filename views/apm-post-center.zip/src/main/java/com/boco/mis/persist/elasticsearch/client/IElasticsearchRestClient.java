package com.boco.mis.persist.elasticsearch.client;
/**
 * es客户端rest服务
 * @author wangyunchao
 *
 * 2018年8月21日 下午3:17:50
 */
public interface IElasticsearchRestClient {

}
