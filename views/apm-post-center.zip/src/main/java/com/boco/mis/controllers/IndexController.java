package com.boco.mis.controllers;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boco.mis.services.IApmdataService;

@RestController
@RequestMapping("/")
public class IndexController {

	@Resource
	private IApmdataService apmdataService;
	
	public IndexController() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/hello")
	public String hello(String msg) {
		return "hello," + msg;
	}
	

}
