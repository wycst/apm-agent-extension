package com.boco.mis.services.impl;

import org.springframework.stereotype.Service;

import com.boco.mis.services.IApmdataService;

@Service("apmdataService")
public class ApmdataServiceImpl implements IApmdataService {

	public ApmdataServiceImpl() {
		// TODO Auto-generated constructor stub
	}

}
