package com.boco.mis.persist.elasticsearch.index;

public class IndexDefineField {

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
