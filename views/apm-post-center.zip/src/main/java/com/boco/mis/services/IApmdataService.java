package com.boco.mis.services;
/**
 * apm data 处理服务
 * @author wangyunchao
 *
 * 2018年8月21日 下午3:34:54
 */
public interface IApmdataService {

//	public Object put();
	
	
}
