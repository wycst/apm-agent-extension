package com.boco.mis.persist.elasticsearch.index;

import java.util.HashMap;

public class IndexDefineField extends HashMap<String,Object>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

//	private String type;
//
//	private boolean fielddata;
//	
//	public String getType() {
//		return type;
//	}
//
//	public void setType(String type) {
//		this.type = type;
//	}
//	
	
}
