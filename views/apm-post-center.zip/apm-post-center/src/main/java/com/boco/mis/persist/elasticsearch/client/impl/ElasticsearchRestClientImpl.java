package com.boco.mis.persist.elasticsearch.client.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseListener;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.boco.mis.persist.elasticsearch.client.IElasticsearchRestClient;
import com.boco.mis.persist.elasticsearch.factory.RestClientFactory;
import com.boco.mis.persist.elasticsearch.index.IndexDefine;
import com.boco.mis.persist.model.ApmModelIndex;
import com.boco.mis.persist.model.ApmTraceInfo;
import com.boco.mis.persist.model.Server;
import com.boco.mis.persist.model.StackTrace;
import com.boco.mis.persist.model.Trace;
import com.boco.mis.persist.model.TraceNode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
@Service
public class ElasticsearchRestClientImpl implements IElasticsearchRestClient {
 
    @Resource
    private RestClientFactory restClientFactory;
    
//    private RestClient restClient;
    
	public RestClient getRestClient() {
//		if(true) {
//			return restClient == null ? restClient = RestClient.builder(
//	                new HttpHost("39.104.110.53", 9200, "http")).build() : restClient;
//		}
		return restClientFactory.getRestClient();
	}

	@PostConstruct
	public void initApmIndexs() {
		try {
			createIndex(IndexDefine.generateIndexDefine(Server.class));
			createIndex(IndexDefine.generateIndexDefine(StackTrace.class));
			createIndex(IndexDefine.generateIndexDefine(Trace.class));
			createIndex(IndexDefine.generateIndexDefine(TraceNode.class));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean existIndex(String indexName) {
		try {
			Response response = getRestClient().performRequest("HEAD",indexName,Collections.<String, String>emptyMap());
			return response.getStatusLine().getReasonPhrase().equals("OK");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	private void createIndex(IndexDefine indexDefine) throws Exception {
		String indexName = indexDefine.indexName();
		if(!existIndex(indexName)) {
			String indexDefineJson = new ObjectMapper().writeValueAsString(indexDefine);
			HttpEntity indexEntity = new NStringEntity(indexDefineJson, ContentType.APPLICATION_JSON);
			getRestClient().performRequest(HttpPut.METHOD_NAME, "/" + indexName, new HashMap<String, String>(), indexEntity);
		}
	}

	public void delete(Map<String,String> params,String index,String type) {
		
		if(params == null) {
			params = new HashMap<String, String>();
			params.put("q", "id:1");
			params.put("pretty", "true");
		}
		try {
			
			Response response = getRestClient().performRequest("DELETE",  "/"+index + "/_query",params);
			System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public void testquery() {
		/*
		 *  curl 'localhost:9200/accounts/person/_search'  -d '
{
  "query" : { "match" : { "desc" : "管理" }},
  "from": 1,
  "size": 1
}'
		 * */
//		HttpEntity entity = new NStringEntity("{\n" +
//                "  \"query\": {\n" +
//                "    \"match_all\": {}\n" +
//                "  }\n" +
//                "}", ContentType.APPLICATION_JSON);

		HttpEntity entity = new NStringEntity("{\n" +
                "  \"query\": {\n" +
         //       "    \"match_all\": {}\n" +
                "    \"match\": {\"desc\" : \"管\"}\n" +
                "  }\n" +
                "  ,\"from\" : 0" +
                "  ,\"size\" : 1" +
                "}", ContentType.APPLICATION_JSON);
		
		try {
			Response response = getRestClient().performRequest("GET", "/accounts/person/_search?pretty", new HashMap<String, String>(),entity);
			System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void addApmIndex(ApmModelIndex model) {
		String indexName = model.indexName();
		
		if(!existIndex(indexName)) {
			try {
				createIndex(IndexDefine.generateIndexDefine(model.getClass()));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		String indexType = model.indexType();
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			HttpEntity entity = new NStringEntity(
					objectMapper.writeValueAsString(model), ContentType.APPLICATION_JSON);
//			Response response = 
			getRestClient().performRequest(HttpPost.METHOD_NAME, "/" + indexName + "/" + indexType + "/" + model.indexId(), Collections.<String, String>emptyMap(),entity);
			// System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void addBulkIndex(ApmModelIndex modelIndex,StringBuffer sb) {
		String indexMeta="{ \"create\" : { \"_index\" : \""+modelIndex.indexName()+"\", \"_type\" : \""+modelIndex.indexType()+"\", \"_id\" : \""+modelIndex.indexId()+"\" } }";
		sb.append(indexMeta).append("\n");
		sb.append(JSON.toJSONString(modelIndex)).append("\n");
	}
	
	public void collect(ApmTraceInfo apmTraceInfo) {
		
		StringBuffer sb = new StringBuffer();
		// addApmIndex(apmTraceInfo.getTrace());
		addBulkIndex(apmTraceInfo.getTrace(),sb);
		
		// 服务
		List<Server>  servers = apmTraceInfo.getServers();
		if(servers != null) {
			for(Server server : servers) {
				// addApmIndex(server);
				addBulkIndex(server,sb);
			}
		}
		
		// trace
		List<TraceNode>  traceNodes = apmTraceInfo.getTraceNodes();
		if(traceNodes != null) {
			
			for(ApmModelIndex modelIndex : traceNodes) {
				// addApmIndex(traceNode);
				addBulkIndex(modelIndex,sb);
			}
		}
		
		List<StackTrace>  stackTraces = apmTraceInfo.getStackTraces();
		if(stackTraces != null) {
			for(StackTrace stackTrace : stackTraces) {
//				addApmIndex(stackTrace);
				addBulkIndex(stackTrace,sb);
			}
		}
		
		// commit !
		HttpEntity entity = new NStringEntity(
				sb.toString(), ContentType.APPLICATION_JSON);
		try {
			getRestClient().performRequest(HttpPost.METHOD_NAME, "/_bulk", Collections.<String, String>emptyMap(),entity);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
