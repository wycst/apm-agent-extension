package com.boco.mis.controllers;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import sun.misc.Contended;

import com.alibaba.fastjson.JSON;
import com.boco.mis.gzip.GZip;
import com.boco.mis.persist.model.ApmTraceInfo;
import com.boco.mis.services.IApmdataService;

@RestController
@RequestMapping("/")
public class IndexController {

	@Resource
	private IApmdataService apmdataService;
	
	public IndexController() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * 测试连接
	 * @param msg
	 * @return
	 */
	@RequestMapping(value = "/connect", method = RequestMethod.HEAD)
	public String connect() {
		return "success";
	}
	
	@PostMapping(value="/trace",produces = {MediaType.APPLICATION_JSON_VALUE})
	public String trace(@RequestBody ApmTraceInfo apmTraceInfo) {
		
		if(apmTraceInfo == null || apmTraceInfo.getTrace() == null)
		    return "error";
		
		apmdataService.collect(apmTraceInfo);
		
		// json格式的字符串
		return "success";
	}
	
}
