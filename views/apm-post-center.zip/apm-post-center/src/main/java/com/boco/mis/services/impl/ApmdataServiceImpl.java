package com.boco.mis.services.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.boco.mis.persist.elasticsearch.client.IElasticsearchRestClient;
import com.boco.mis.persist.model.ApmTraceInfo;
import com.boco.mis.services.IApmdataService;

@Service("apmdataService")
public class ApmdataServiceImpl implements IApmdataService {

	@Resource
	private IElasticsearchRestClient elasticsearchRestClient;
	
	public ApmdataServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	
	
	public void collect(ApmTraceInfo apmTraceInfo) {
		
		//1 加载配置判断储存方式
		
		//2  
		elasticsearchRestClient.collect(apmTraceInfo);
		
	}

}
