package com.boco.mis.opentrace.data.server;

public class Database extends Server {

	private String url;

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

}
