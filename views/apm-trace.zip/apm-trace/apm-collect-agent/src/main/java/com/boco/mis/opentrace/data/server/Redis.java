package com.boco.mis.opentrace.data.server;

public class Redis extends Server {

}
