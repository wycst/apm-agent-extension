package com.boco.mis.opentrace.data.server;

public class WebServer extends Server {

}
