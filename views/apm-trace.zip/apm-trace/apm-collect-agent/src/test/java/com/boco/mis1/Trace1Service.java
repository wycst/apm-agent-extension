package com.boco.mis1;

import net.bytebuddy.ByteBuddy;
import net.bytebuddy.agent.Installer;

public final class Trace1Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
