package com.boco.mis.persist.model;

public abstract class ApmModelIndex {

	public abstract String indexId();
	
	public abstract String indexName();
	
	public abstract String indexType();
	
}
