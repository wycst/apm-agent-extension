package com.boco.mis.persist.model;

import com.boco.mis.persist.elasticsearch.annotation.EsIndex;
import com.boco.mis.persist.elasticsearch.annotation.EsIndexField;

@EsIndex(indexName = "trace_logs", indexType = "default_log")
public class TraceLog extends ApmModelIndex {

	static final String INDEX_NAME = "trace_logs";
	static final String INDEX_TYPE = "default_log";
	
	@EsIndexField(fieldName = "id", fieldType = "keyword")
	private String id;
	
	@EsIndexField(fieldName = "log", fieldType = "text")
	private String log;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}
	
	public String indexName() {
		return INDEX_NAME;
	}

	public String indexType() {
		return INDEX_TYPE;
	}
	
	public String indexId() {
		return id;
	}
	
}
