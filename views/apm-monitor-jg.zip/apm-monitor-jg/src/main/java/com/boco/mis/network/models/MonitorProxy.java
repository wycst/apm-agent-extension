package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;

@Table(name="monitor_proxy")
public class MonitorProxy {
	
	@Id
	@Column
	private int id;
	
	@Column(name = "proxy_host")
	private String proxyHost;
	
	@Column(name = "proxy_port")
	private String proxyPort;
	
	@Column
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public String getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
