package com.boco.mis.network.monitor;

import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.boco.mis.network.context.AppContext;
import com.boco.mis.network.dao.NetMonitorDao;
import com.boco.mis.network.models.MonitorTcpResult;
import com.boco.mis.network.models.MonitorTcpinfo;

public class MonitorTcpHandler {

	private static Logger logger = Logger.getLogger(MonitorTcpHandler.class);
		
	public static void monitor(MonitorTcpinfo info) {
		
		MonitorTcpResult resultInfo = new MonitorTcpResult();
		resultInfo.setTcpId(info.getId());
		resultInfo.setTcpHostportpair(info.getTcpHost() + ":" + info.getTcpPort());
		resultInfo.setBusiSysId(info.getBusiSysId());
		
		long beginMills = System.currentTimeMillis();
		resultInfo.setBeginMills(beginMills);
		
		long timeout = info.getTimeout();

		int connectCount = info.getConnectCount();
		if(connectCount <= 0 ) {
			connectCount = 1;
		}
		int resCode = -1;
		int count = 0;
		String errorText = null;
		while(resCode == -1 && count++ < connectCount) {
			try {
				logger.info("========= tcp连接... " + resultInfo.getTcpHostportpair());
				doMonitor(info);
				logger.info("==========连接成功======== ");
			} catch (Exception ex) {
				if(count == connectCount) {
					ex.printStackTrace();
				}
				errorText = ex.getMessage();
				if(ex instanceof java.net.ConnectException) {
					errorText = "创建连接错误:" +  errorText;
				} else if(ex instanceof java.net.SocketTimeoutException){
					errorText = "连接响应超时:" + errorText;
				}  else {
					errorText = "连接失败：" + errorText;
				}
			}
		}
		if(errorText == null) {
			resultInfo.setAvailable(true);
		}
		long endMills = System.currentTimeMillis();
		resultInfo.setEndMills(endMills);
		resultInfo.setEndTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(new Date(endMills)));
		resultInfo.setTimeMills(endMills - beginMills);
		
		resultInfo.setErrorText(errorText);
		Date beginDate = new Date(beginMills);
		resultInfo.setBeginTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(beginDate));
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(beginMills);
		resultInfo.setMonth(cal.get(Calendar.MONTH) + 1);
		resultInfo.setDay(cal.get(Calendar.DAY_OF_MONTH));
		
		// save2db 
		NetMonitorDao dao = AppContext.getContext().getBean(NetMonitorDao.class);
		// false -> 自动提交事物
		try {
			dao.insertModel(resultInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void doMonitor(MonitorTcpinfo info) throws Exception {
		String host = info.getTcpHost();
		int port = info.getTcpPort();
		Socket sck = null;
		try {
			sck = new Socket(host, port);
		} catch(Exception ex) {
			throw ex;
		} finally {
			if(sck != null) {
				sck.close();
			}
		}
	}
	
}
