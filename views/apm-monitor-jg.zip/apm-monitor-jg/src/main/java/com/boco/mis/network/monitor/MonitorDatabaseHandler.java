package com.boco.mis.network.monitor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.boco.mis.network.context.AppContext;
import com.boco.mis.network.dao.NetMonitorDao;
import com.boco.mis.network.models.MonitorDatabaseResult;
import com.boco.mis.network.models.MonitorDatabaseinfo;

public class MonitorDatabaseHandler {

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static Logger logger = Logger.getLogger(MonitorDatabaseHandler.class);
	
	public static void monitor(MonitorDatabaseinfo info) {
		
		MonitorDatabaseResult resultInfo = new MonitorDatabaseResult();
		resultInfo.setDatabaseId(info.getId());
		resultInfo.setDatabaseUrl(info.getDatabaseUrl());
		resultInfo.setBusiSysId(info.getBusiSysId());
		
		long beginMills = System.currentTimeMillis();
		resultInfo.setBeginMills(beginMills);
		String errorText = null;
		try {
			logger.info("========= 数据库连接测试 ... url = " + resultInfo.getDatabaseUrl());
			doMonitor(info,resultInfo);
			logger.info("==========测试结束成功======== ");
		} catch (Exception ex) {
			
		}
		
		if(resultInfo.getErrorText() == null) {
			resultInfo.setAvailable(true);
		}
		resultInfo.setValidateExpr(info.getValidateExpr());
		
		long endMills = System.currentTimeMillis();
		resultInfo.setEndMills(endMills);
		resultInfo.setEndTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(new Date(endMills)));
		resultInfo.setTimeMills(endMills - beginMills);
		
		Date beginDate = new Date(beginMills);
		resultInfo.setBeginTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(beginDate));
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(beginMills);
		resultInfo.setMonth(cal.get(Calendar.MONTH) + 1);
		resultInfo.setDay(cal.get(Calendar.DAY_OF_MONTH));
		
		// save2db 
		NetMonitorDao dao = AppContext.getContext().getBean(NetMonitorDao.class);
		// false -> 自动提交事物
		try {
			dao.insertModel(resultInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String doMonitor(MonitorDatabaseinfo info,
			MonitorDatabaseResult resultInfo) {
		
		Connection conn = null;
		PreparedStatement ps = null;
		
		String exceptionMsg = null;
		try {
			String dbUrl = info.getDatabaseUrl();
			String user = info.getDatabaseUser();
			String pwd = info.getDatabasePwd();
			
			String databaseType = info.getDatabaseType();
		    conn = DriverManager.getConnection(dbUrl,user,pwd);
			
		    String querySql = info.getQuerySql();
		    ps = conn.prepareStatement(querySql);
		    ResultSet rs = ps.executeQuery();
		    ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
		    Map<String, Object> rowData = new HashMap<String, Object>();
		    if(rs.next()) {
		    	// 如果有只取第一条记录
				for (int i = 0; i < columnCount; i++) {
					String fieldName = rsmd.getColumnLabel(i + 1);
					rowData.put(fieldName, rs.getString(fieldName));
				}	    	
		    }
		    
		    String validateExpr = info.getValidateExpr();
		    int validate = doValidate(rowData,validateExpr);
		    resultInfo.setValidate(validate);
		    resultInfo.setQuerySqlReturnval(JSON.toJSONString(rowData));
		    
		    rs.close();
		    ps.close();
		} catch (Exception ex) {
			ex.printStackTrace();
			exceptionMsg = ex.getMessage();
			resultInfo.setErrorText("表达式校验失败！");
			
		} finally {
			if(conn != null) {
				resultInfo.setAvailable(true);
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				resultInfo.setErrorText("创建数据库连接失败" + (exceptionMsg == null ? "!" : "," + exceptionMsg));
			}
		}
		return null;
	}

	private static int doValidate(Map<String, Object> rowData,
			String validateExpr) {
		
		if(rowData.size() == 0 || validateExpr == null || validateExpr.length() == 0) {
			return 0;
		}
		List<Map> validates = JSON.parseArray(validateExpr, Map.class);
		// 校验规则暂定如下：
		// 只要有一个AND false直接返回-1，只要有一个OR true直接返回1
		// 缺省情况 AND true && OR false 只要存在一个AND 返回1，否则返回-1
		boolean validate = false;
		for(Map validateInfo : validates) {
			String conn = (String) validateInfo.get("conn").toString().trim();
			String col = (String) validateInfo.get("col").toString().trim();
			String o = (String) validateInfo.get("o").toString().trim();
			String v = (String) validateInfo.get("v").toString().trim();
			if(!rowData.containsKey(col)) {
				// 如果没有校验失败
				return -1;
			}
			String queryValue = rowData.get(col) + "";
			if("=".equals(o)) {
				if(queryValue.equals(v)) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if("!=".equals(o)) {
				// 转化为number进行比较
				if(!queryValue.equals(v)) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if(">=".equals(o)) {
				// 转化为number进行比较
				double queryNum = Double.parseDouble(queryValue);
				double cNum = Double.parseDouble(v);
				if(queryNum >= cNum) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if(">".equals(o)) {
				// 转化为number进行比较
				double queryNum = Double.parseDouble(queryValue);
				double cNum = Double.parseDouble(v);
				if(queryNum > cNum) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if("<=".equals(o)) {
				// 转化为number进行比较
				double queryNum = Double.parseDouble(queryValue);
				double cNum = Double.parseDouble(v);
				if(queryNum <= cNum) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if("<".equals(o)) {
				// 转化为number进行比较
				double queryNum = Double.parseDouble(queryValue);
				double cNum = Double.parseDouble(v);
				if(queryNum < cNum) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			} else if("LIKE".equals(o)) {
				// 转化为number进行比较
				if(queryValue.indexOf(v) > -1) {
					if("OR".equals(conn)) {
						return 1;
					} else {
						validate = true;
					}
				} else {
					if("AND".equals(conn)) {
						return -1;
					} 
				}
			}
		}
		if(validate) {
			return 1;
		}
		return -1;
	}
	
}
