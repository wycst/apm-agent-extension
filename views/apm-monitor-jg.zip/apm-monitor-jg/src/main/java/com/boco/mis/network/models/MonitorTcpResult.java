package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;

@Table(name="monitor_tcp_result")
public class MonitorTcpResult {

	@Id
	@Column
	private int id;
	
	@Column(name = "tcp_id")
	private int tcpId ;
	
	@Column(name="busi_sys_id")
	private int busiSysId;

	@Column(name="tcp_hostportpair")
	private String tcpHostportpair;
	
	// 开始时间     格式 yyyy-MM-dd HH:mm:ss.SSS  保留毫秒数
	@Column(name="begin_time")
	private String beginTime;
	
	// 结束时间     格式 yyyy-MM-dd HH:mm:ss.SSS
	@Column(name="end_time")
	private String endTime;
	
	// 开始毫秒数
	@Column(name="begin_mills")
	private long beginMills;
	
	// 结束毫秒数
	@Column(name="end_mills")
	private long endMills;
	
	// 耗时数
	@Column(name="time_mills")
	private long timeMills;
	
	@Column
	private int month;
	
	@Column
	private int day;
	
	// 是否可用（可连通）
	@Column
	private boolean available;
	
	// 错误文本信息
	@Column(name="error_text")
	private String errorText;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTcpId() {
		return tcpId;
	}

	public void setTcpId(int tcpId) {
		this.tcpId = tcpId;
	}

	public int getBusiSysId() {
		return busiSysId;
	}

	public void setBusiSysId(int busiSysId) {
		this.busiSysId = busiSysId;
	}

	public String getTcpHostportpair() {
		return tcpHostportpair;
	}

	public void setTcpHostportpair(String tcpHostportpair) {
		this.tcpHostportpair = tcpHostportpair;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public long getBeginMills() {
		return beginMills;
	}

	public void setBeginMills(long beginMills) {
		this.beginMills = beginMills;
	}

	public long getEndMills() {
		return endMills;
	}

	public void setEndMills(long endMills) {
		this.endMills = endMills;
	}

	public long getTimeMills() {
		return timeMills;
	}

	public void setTimeMills(long timeMills) {
		this.timeMills = timeMills;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

}
