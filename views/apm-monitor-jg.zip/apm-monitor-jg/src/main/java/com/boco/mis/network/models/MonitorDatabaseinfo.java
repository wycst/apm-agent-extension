package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;
import com.boco.mis.network.quartz.JobKeyData;

@Table(name="monitor_databaseinfo")
public class MonitorDatabaseinfo implements JobKeyData {
	
	@Id
	@Column
	private int id ;
	
	@Column(name="database_host")
	private String databaseHost;
	
	@Column(name="database_port")
	private int databasePort;
	
	@Column(name="device_name")
	private String deviceName;
	
	@Column
	private String descinfo;
	
	@Column(name="busi_sys_id")
	private int busiSysId;
	
	private MonitorBusiSys busiSys;
	
	@Column(name="proxy_id")
	private int proxyId;
	
	private String proxyHost;
	
	private int proxyPort;
	
	@Column(name="database_instance")
	private String databaseInstance;
	
	@Column(name="database_user")
	private String databaseUser;
	
	@Column(name="database_pwd")
	private String databasePwd;
	
	@Column(name="database_type")
	private String databaseType;
	
	@Column(name="database_url")
	private String databaseUrl;
	
	@Column(name="query_sql")
	private String querySql;
	
	@Column(name="validate_expr")
	private String validateExpr;
	
	@Column(name="cron_expr")
	private String cronExpr = "* */10 8-18 * * ?";
	
	// 从几点开始
	@Column(name="from_hour_of_day")
	private String fromHourOfDay = "8";
	
	// 到几点结束
	@Column(name="to_hour_of_day")
	private String toHourOfDay = "18";
	
	// 间隔分钟
	@Column(name="interval_minute")
	private String intervalMinute = "10";
	
	// 超时毫秒数ms
	@Column
	private long timeout = 10000;
	
	// 连接次数
	@Column(name="connect_count")
	private int connectCount = 3;
	
	// 监控状态
	@Column(name="monitor_state")
	private boolean monitorState = true;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDatabaseHost() {
		return databaseHost;
	}

	public void setDatabaseHost(String databaseHost) {
		this.databaseHost = databaseHost;
	}

	public int getDatabasePort() {
		return databasePort;
	}

	public void setDatabasePort(int databasePort) {
		this.databasePort = databasePort;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDescinfo() {
		return descinfo;
	}

	public void setDescinfo(String descinfo) {
		this.descinfo = descinfo;
	}

	public int getBusiSysId() {
		return busiSysId;
	}

	public void setBusiSysId(int busiSysId) {
		this.busiSysId = busiSysId;
	}

	public String getDatabaseUser() {
		return databaseUser;
	}

	public void setDatabaseUser(String databaseUser) {
		this.databaseUser = databaseUser;
	}

	public String getDatabasePwd() {
		return databasePwd;
	}

	public void setDatabasePwd(String databasePwd) {
		this.databasePwd = databasePwd;
	}

	public String getDatabaseType() {
		return databaseType;
	}

	public void setDatabaseType(String databaseType) {
		this.databaseType = databaseType;
	}

	public String getDatabaseUrl() {
		return databaseUrl;
	}

	public void setDatabaseUrl(String databaseUrl) {
		this.databaseUrl = databaseUrl;
	}

	public String getQuerySql() {
		return querySql;
	}

	public void setQuerySql(String querySql) {
		this.querySql = querySql;
	}

	public String getValidateExpr() {
		return validateExpr;
	}

	public void setValidateExpr(String validateExpr) {
		this.validateExpr = validateExpr;
	}

	public String getCronExpr() {
		return cronExpr;
	}

	public void setCronExpr(String cronExpr) {
		this.cronExpr = cronExpr;
	}

	public String getFromHourOfDay() {
		return fromHourOfDay;
	}

	public void setFromHourOfDay(String fromHourOfDay) {
		this.fromHourOfDay = fromHourOfDay;
	}

	public String getToHourOfDay() {
		return toHourOfDay;
	}

	public void setToHourOfDay(String toHourOfDay) {
		this.toHourOfDay = toHourOfDay;
	}

	public String getIntervalMinute() {
		return intervalMinute;
	}

	public void setIntervalMinute(String intervalMinute) {
		this.intervalMinute = intervalMinute;
	}

	public long getTimeout() {
		return timeout;
	}

	public void setTimeout(long timeout) {
		this.timeout = timeout;
	}

	public int getConnectCount() {
		return connectCount;
	}

	public void setConnectCount(int connectCount) {
		this.connectCount = connectCount;
	}

	public boolean isMonitorState() {
		return monitorState;
	}

	public void setMonitorState(boolean monitorState) {
		this.monitorState = monitorState;
	}

	public MonitorBusiSys getBusiSys() {
		return busiSys;
	}

	public void setBusiSys(MonitorBusiSys busiSys) {
		this.busiSys = busiSys;
	}

	public int getProxyId() {
		return proxyId;
	}

	public void setProxyId(int proxyId) {
		this.proxyId = proxyId;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public int getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}

	public String getDatabaseInstance() {
		return databaseInstance;
	}

	public void setDatabaseInstance(String databaseInstance) {
		this.databaseInstance = databaseInstance;
	}

	@Override
	public String getJobKeyName() {
		return this.getId() + "";
	}

	@Override
	public String getJobKeyGroup() {
		return this.getBusiSysId() + "";
	}

	@Override
	public String getDescription() {
		return this.getDeviceName();
	}
	

}
