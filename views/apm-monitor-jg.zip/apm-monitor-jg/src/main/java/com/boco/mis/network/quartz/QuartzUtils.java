package com.boco.mis.network.quartz;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;


public class QuartzUtils {

	private static Logger logger = Logger.getLogger(QuartzUtils.class);

	public static JobKey buildJobKey(JobKeyData dataInfo) {
		return new JobKey(dataInfo.getJobKeyName(), dataInfo.getJobKeyGroup());
	}

	public static JobDetail buildJobDetail(JobKeyData dataInfo) {
		
		org.quartz.JobDataMap dataMap = new org.quartz.JobDataMap();
		dataMap.put("data", dataInfo);
		JobKey jobKey = buildJobKey(dataInfo);
		JobDetail jb = JobBuilder.newJob(MonitorJob.class)
				.withDescription(dataInfo.getDescription()) //
				.withIdentity(jobKey.getName(), jobKey.getGroup()) // job
																	// 的name和group
				.usingJobData(dataMap).build();
		return jb;
	}

	public static Trigger buildTrigger(JobKeyData dataInfo) {
		String cronExpr = "0/2 * * * * ?";//
		cronExpr = dataInfo.getCronExpr();
		Trigger t = TriggerBuilder.newTrigger().withDescription("")
				.withIdentity(dataInfo.getJobKeyName(), dataInfo.getJobKeyGroup())
				.withSchedule(CronScheduleBuilder.cronSchedule(cronExpr))
				.build();
		return t;
	}

	public static void scheduleJob(JobKeyData dataInfo) {
		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.scheduleJob(buildJobDetail(dataInfo),
					buildTrigger(dataInfo));
			logger.info(" scheduler start status : " + scheduler.isStarted());
			if (!scheduler.isStarted() || scheduler.isShutdown()) {
				logger.info(" scheduler start call! ");
				scheduler.start();
			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * stop timer
	 * 
	 * @param coreset
	 */
	public static void stopQuartzTimer(JobKeyData dataInfo) {
		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			if (scheduler.isStarted()) {
				TriggerKey triggerKey = TriggerKey.triggerKey(
						dataInfo.getJobKeyName(), dataInfo.getJobKeyGroup());
				
				if(triggerKey != null) {
					// 停止
					scheduler.pauseTrigger(triggerKey);
					// 移除
					scheduler.unscheduleJob(triggerKey);
					scheduler.deleteJob(buildJobKey(dataInfo));
				}
			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 关闭调度
	 */
	public static void stopScheduler() {
		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.clear();
			if (!scheduler.isShutdown()) {
				scheduler.shutdown();
			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * 启动定时
	 * 
	 * @param coreset
	 */
	public static void startQuartzTimer(JobKeyData dataInfo) {
		stopQuartzTimer(dataInfo);
		scheduleJob(dataInfo);
	}

	/**
	 * 更新QuartzTimer
	 * 
	 * @param cronExpr
	 */
	public static void updateQuartzTimer(JobKeyData dataInfo) {

		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			TriggerKey triggerKey = TriggerKey.triggerKey(dataInfo.getJobKeyName(),
					dataInfo.getJobKeyGroup());
			CronTrigger trigger = (CronTrigger) scheduler
					.getTrigger(triggerKey);
			if (trigger == null) {
				startQuartzTimer(dataInfo);
				return;
			}

			TriggerBuilder<Trigger> triggerBuilder = TriggerBuilder
					.newTrigger();
			// 触发器名,触发器组
			triggerBuilder.withIdentity(dataInfo.getJobKeyName(),
					dataInfo.getJobKeyGroup());
			triggerBuilder.startNow();
			triggerBuilder.withSchedule(CronScheduleBuilder
					.cronSchedule(dataInfo.getCronExpr()));
			// 创建Trigger对象
			trigger = (CronTrigger) triggerBuilder.build();
			scheduler.rescheduleJob(triggerKey, trigger);
			// }
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	public static Map<String, Object> getFireTimeInfo(JobKeyData dataInfo) {
		Map<String, Object> fireTimeInfo = new HashMap<String, Object>();
		fireTimeInfo.put("prevFireTime", "-");
		fireTimeInfo.put("nextFireTime", "-");
		try {
			Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
			TriggerKey triggerKey = TriggerKey.triggerKey(dataInfo.getJobKeyName(),
					dataInfo.getJobKeyGroup());
			CronTrigger trigger = (CronTrigger) scheduler
					.getTrigger(triggerKey);
			if (trigger != null) {
				Date previousFireTime = trigger.getPreviousFireTime();
				Date nextFireTime = trigger.getNextFireTime();
				fireTimeInfo
						.put("prevFireTime",
								previousFireTime == null ? "-"
										: new SimpleDateFormat(
												"yyyy-MM-dd HH:mm:ss")
												.format(previousFireTime));
				fireTimeInfo.put("nextFireTime",
						nextFireTime == null ? "-" : new SimpleDateFormat(
								"yyyy-MM-dd HH:mm:ss").format(nextFireTime));
			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fireTimeInfo;
	}

}
