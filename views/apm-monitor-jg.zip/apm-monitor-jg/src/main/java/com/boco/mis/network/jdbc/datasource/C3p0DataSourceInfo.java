package com.boco.mis.network.jdbc.datasource;

import java.io.InputStream;
import java.util.Properties;

public class C3p0DataSourceInfo {

	private static String driverClass;
	private static String url;
	private static String username;
	private static String password;
	private static int maxPoolSize;
	private static int minPoolSize;
	private static int acquireIncrement;
	private static int initialPoolSize;
	private static int maxIdleTime;

	static {

		Properties props = new Properties();
		try {
			InputStream is = C3p0DataSourceInfo.class
					.getResourceAsStream("/db.properties");
			props.load(is);
			driverClass = props.getProperty("driverClass");
			url = props.getProperty("url");
			username = props.getProperty("username");
			password = props.getProperty("password");

			maxPoolSize = Integer.parseInt(props.getProperty("maxPoolSize"));
			minPoolSize = Integer.parseInt(props.getProperty("minPoolSize"));
			acquireIncrement = Integer.parseInt(props.getProperty("acquireIncrement"));
			initialPoolSize = Integer.parseInt(props.getProperty("initialPoolSize"));
	        maxIdleTime = Integer.parseInt(props.getProperty("maxIdleTime"));
			
		} catch (Throwable t) {
			t.printStackTrace();
		} finally {

		}
		
	}

	public static String getDriverClass() {
		return driverClass;
	}

	public static String getUrl() {
		return url;
	}

	public static String getUsername() {
		return username;
	}

	public static String getPassword() {
		return password;
	}

	public static int getMaxPoolSize() {
		return maxPoolSize;
	}

	public static int getMinPoolSize() {
		return minPoolSize;
	}

	public static int getAcquireIncrement() {
		return acquireIncrement;
	}

	public static int getInitialPoolSize() {
		return initialPoolSize;
	}

	public static int getMaxIdleTime() {
		return maxIdleTime;
	}

	
	
}
