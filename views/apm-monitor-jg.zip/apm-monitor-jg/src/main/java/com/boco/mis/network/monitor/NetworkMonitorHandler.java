package com.boco.mis.network.monitor;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;

import org.apache.log4j.Logger;

import com.boco.mis.network.context.AppContext;
import com.boco.mis.network.dao.NetMonitorDao;
import com.boco.mis.network.models.MonitorNetworkResult;
import com.boco.mis.network.models.MonitorNetworkinfo;

public class NetworkMonitorHandler {

	// 
    private static Logger logger = Logger.getLogger(NetworkMonitorHandler.class);
	
    static {
    	// -Dhttps.protocols=TLSv1,SSLv3
    	if(System.getProperty("https.protocols") == null) {
    		System.setProperty("https.protocols", "TLSv1,SSLv3");		
    	}
		try {
			SSLContext sslcontext = SSLContext.getInstance("SSL", "SunJSSE");
			TrustManager[] tm = { new X509TrustManagerImpl() };
			sslcontext.init(null, tm, new SecureRandom());
			HostnameVerifier ignoreHostnameVerifier = new HostnameVerifier() {
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}
			};
			HttpsURLConnection
					.setDefaultHostnameVerifier(ignoreHostnameVerifier);
			HttpsURLConnection.setDefaultSSLSocketFactory(sslcontext
					.getSocketFactory());

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    
    private static Map<String,Proxy> httpProxyMap = new HashMap<String,Proxy>();
    private static Proxy getHttpProxy(String host, int port) {
    	String proxyCacheKey = host + ":" + port;
    	Proxy httpProxy = httpProxyMap.get(proxyCacheKey);
    	if(httpProxy == null) {
    		InetSocketAddress proxyAddr = new InetSocketAddress(host, port);
    		httpProxy = new Proxy(Proxy.Type.HTTP, proxyAddr); 
    	}
		return httpProxy;
	}
    
	public static int doMonitor(MonitorNetworkinfo info) throws Exception {
		String url = info.getUrl();
		long timeout = info.getTimeout();
		
		int proxyId = info.getProxyId();
		String host = info.getProxyHost();
		int port = info.getProxyPort();
		Proxy httpProxy = null;
		if(proxyId > 0 && host != null && port > 0) {
			httpProxy = getHttpProxy(host,port);
		}
		URLConnection conn = null;
		if(httpProxy != null) {
			conn = new URL(url).openConnection(httpProxy);
		} else {
			conn = new URL(url).openConnection();
		}
		// 暂定连接时间和响应时间一致
		conn.setConnectTimeout((int) timeout);
		conn.setReadTimeout((int) timeout);
		if (conn instanceof HttpURLConnection) {
			HttpURLConnection httpConn = (HttpURLConnection) conn;
//			httpConn.setRequestMethod("HEAD");
			httpConn.setRequestMethod("GET");
			int resCode = httpConn.getResponseCode();
			return resCode;
		}
		return -1;
	}

	public static void monitor(MonitorNetworkinfo info) {
		MonitorNetworkResult resultInfo = new MonitorNetworkResult();
		resultInfo.setNetworkId(info.getId());
		resultInfo.setBusiSysId(info.getBusiSysId());
		resultInfo.setUrl(info.getUrl());
		long beginMills = System.currentTimeMillis();
		resultInfo.setBeginMills(beginMills);
		
		long timeout = info.getTimeout();
		resultInfo.setStandardTimeout(timeout);

		int connectCount = info.getConnectCount();
		if(connectCount <= 0 ) {
			connectCount = 1;
		}
		int resCode = -1;
		int count = 0;
		String errorText = null;
		while(resCode == -1 && count++ < connectCount) {
			try {
				logger.info("========= 第" + count + "次开始连接... " + info.getUrl());
				resCode = doMonitor(info);
				logger.info("==========响应成功=========状态码：" + resCode);
			} catch (Exception ex) {
				if(count == connectCount) {
					ex.printStackTrace();
				}
				errorText = ex.getMessage();
				if(ex instanceof java.net.UnknownHostException) {
					errorText = "无法访问的域名错误:" +  errorText;
					// 非超时异常直接断
					ex.printStackTrace();
				    break;
				} else if(ex instanceof java.net.ConnectException) {
					errorText = "创建连接错误:" +  errorText;
				} else if(ex instanceof java.net.SocketTimeoutException){
					errorText = "连接响应超时:" + errorText;
				} 
			}
		}
		if(resCode >= 200 && resCode < 400) {
			// 2xx和3xx暂时都认为成功！
			resultInfo.setAvailable(true);
		} else {
			if(resCode < 500 && resCode >= 400) {
				errorText = "客户端错误！";
			} else if(resCode < 600 && resCode >= 500) {
				errorText = "服务端错误！";
			} else {
				if(errorText == null) {
					errorText = "其他错误，请参考响应码["+resCode+"]！";
				}
 			}
		}
		resultInfo.setResCode(resCode);
		
		long endMills = System.currentTimeMillis();
		resultInfo.setEndMills(endMills);
		resultInfo.setEndTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(new Date(endMills)));
		resultInfo.setTimeMills(endMills - beginMills);
		
		resultInfo.setErrorText(errorText);
		
		Date beginDate = new Date(beginMills);
		resultInfo.setBeginTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(beginDate));
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(beginMills);
		resultInfo.setMonth(cal.get(Calendar.MONTH) + 1);
		resultInfo.setDay(cal.get(Calendar.DAY_OF_MONTH));
		
		// save2db 
		NetMonitorDao dao = AppContext.getContext().getBean(NetMonitorDao.class);
		// false -> 自动提交事物
		try {
			dao.insertModel(resultInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		MonitorNetworkinfo info = new MonitorNetworkinfo();
		info.setUrl("https://www.baidu.com");
//		info.setUrl("https://117.136.129.29:8050/EMAPAdmin/adminlogininfo.do?locale=cn");
		info.setTimeout(30000);
		info.setConnectCount(30000);
		info.setConnectCount(3);
		try {
			int code = doMonitor(info);
			System.out.println(code);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
