package com.boco.mis.network.monitor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.boco.mis.network.context.AppContext;
import com.boco.mis.network.dao.NetMonitorDao;
import com.boco.mis.network.models.MonitorPingResult;
import com.boco.mis.network.models.MonitorPinginfo;
import com.boco.mis.network.models.MonitorTcpResult;

public class MonitorPinginfoHandler {

	private static Logger logger = Logger.getLogger(MonitorPinginfoHandler.class);
	
	//若line含有=18ms TTL=16字样,说明已经ping通,返回1,否則返回0.
    private static int getCheckResult(String line) {   
        Pattern pattern = Pattern.compile("(\\d+ms)(\\s+)(TTL=\\d+)",    Pattern.CASE_INSENSITIVE);  
        Matcher matcher = pattern.matcher(line);  
        while (matcher.find()) {
            return 1;
        }
        return 0; 
    }
	
	public static void monitor(MonitorPinginfo info) {
		MonitorPingResult resultInfo = new MonitorPingResult();
		resultInfo.setPingId(info.getId());
		resultInfo.setPingIp(info.getPingIp());
		resultInfo.setBusiSysId(info.getBusiSysId());
		
		long beginMills = System.currentTimeMillis();
		resultInfo.setBeginMills(beginMills);
		
		long timeout = info.getTimeout();

		int connectCount = info.getConnectCount();
		if(connectCount <= 0 ) {
			connectCount = 1;
		}
		boolean error = false;
		int count = 0;
		String errorText = null;
		try {
			logger.info("========= ping host... " + resultInfo.getPingIp());
			doMonitor(info,resultInfo);
			logger.info("==========连接成功======== ");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		long endMills = System.currentTimeMillis();
		resultInfo.setEndMills(endMills);
		resultInfo.setEndTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(new Date(endMills)));
		resultInfo.setTimeMills(endMills - beginMills);
		
		resultInfo.setErrorText(errorText);
		Date beginDate = new Date(beginMills);
		resultInfo.setBeginTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
				.format(beginDate));
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(beginMills);
		resultInfo.setMonth(cal.get(Calendar.MONTH) + 1);
		resultInfo.setDay(cal.get(Calendar.DAY_OF_MONTH));
		
		// save2db 
		NetMonitorDao dao = AppContext.getContext().getBean(NetMonitorDao.class);
		// false -> 自动提交事物
		try {
			dao.insertModel(resultInfo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void doMonitor(MonitorPinginfo info, MonitorPingResult resultInfo) {
		
		String ipAddress = info.getPingIp();
		int pingPacketNum = info.getPingPacketNum();
		long timeOut = info.getTimeout();
		
		if(timeOut == 0) timeOut = 30000;
	    BufferedReader in = null;  
        Runtime r = Runtime.getRuntime();  // 将要执行的ping命令,此命令是windows格式的命令  
        String pingCommand = "ping " + ipAddress + " -n " + pingPacketNum    + " -w " + timeOut;  
        try {   // 执行命令并获取输出  
        	logger.info(pingCommand);   
            Process p = r.exec(pingCommand);   
            if (p == null) {    
                return ;   
            }
            in = new BufferedReader(new InputStreamReader(p.getInputStream()));   // 逐行检查输出,计算类似出现=23ms TTL=62字样的次数  
            int connectedCount = 0;   
            String line = null;   
            // 计算丢包率和平均延时
            int avgDelay = 0;
            String packetLoss = "";
            while ((line = in.readLine()) != null) {    
                connectedCount += getCheckResult(line);   
                line = line.trim();
                int s = line.indexOf('(');
                int e = line.indexOf(')');
                int pIndex = -1;
                if(s > -1 && e > -1 && (pIndex = line.indexOf('%')) > -1) {
                	packetLoss = line.substring(s + 1, pIndex + 1);
                }
                //  平均 = 1ms
                if(line.indexOf("= ") > -1 && line.indexOf("ms") > -1) {
                	int avgDelayFromIndex = line.lastIndexOf("= ") + 2;
                	int avgDelayToIndex = line.lastIndexOf("ms");
                	avgDelay = Integer.parseInt(line.substring(avgDelayFromIndex, avgDelayToIndex));
                }
            }  
            if(connectedCount > 0) {
            	resultInfo.setAvailable(true);
                resultInfo.setAvgDelay(avgDelay);
                resultInfo.setPacketLoss(packetLoss);
            } else {
            	resultInfo.setPacketLoss("100%");
            }
        } catch (Exception ex) {   
            ex.printStackTrace();   // 出现异常则返回假  
        } finally {   
            try {    
                in.close();   
            } catch (IOException e) {    
                e.printStackTrace();   
            }  
        }
		
	}

}
