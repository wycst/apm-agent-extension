package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;
import com.boco.mis.network.quartz.JobKeyData;

@Table(name="monitor_pinginfo")
public class MonitorPinginfo implements JobKeyData {

	@Id
	@Column
	private int id ;
	
	@Column(name="ping_ip")
	private String pingIp;
	
	@Column(name="ping_packet_num")
	private int pingPacketNum;
	
	@Column(name="device_name")
	private String deviceName;
	
	@Column
	private String descinfo;
	
	@Column(name="busi_sys_id")
	private int busiSysId;
	
	@Column(name="proxy_id")
	private int proxyId;
	
	private String proxyHost;
	
	private int proxyPort;
	
	@Column(name="cron_expr")
	private String cronExpr = "* */10 8-18 * * ?";
	
	// 从几点开始
	@Column(name="from_hour_of_day")
	private String fromHourOfDay = "8";
	
	// 到几点结束
	@Column(name="to_hour_of_day")
	private String toHourOfDay = "18";
	
	// 间隔分钟
	@Column(name="interval_minute")
	private String intervalMinute = "10";
	
	// 超时毫秒数ms
	@Column
	private long timeout = 10000;
	
	// 连接次数
	@Column(name="connect_count")
	private int connectCount = 3;
	
	// 监控状态
	@Column(name="monitor_state")
	private boolean monitorState = true;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPingIp() {
		return pingIp;
	}

	public void setPingIp(String pingIp) {
		this.pingIp = pingIp;
	}

	public int getPingPacketNum() {
		return pingPacketNum;
	}

	public void setPingPacketNum(int pingPacketNum) {
		this.pingPacketNum = pingPacketNum;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getDescinfo() {
		return descinfo;
	}

	public void setDescinfo(String descinfo) {
		this.descinfo = descinfo;
	}

	public int getBusiSysId() {
		return busiSysId;
	}

	public void setBusiSysId(int busiSysId) {
		this.busiSysId = busiSysId;
	}

	public int getProxyId() {
		return proxyId;
	}

	public void setProxyId(int proxyId) {
		this.proxyId = proxyId;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public int getProxyPort() {
		return proxyPort;
	}

	public void setProxyPort(int proxyPort) {
		this.proxyPort = proxyPort;
	}

	public String getCronExpr() {
		return cronExpr;
	}

	public void setCronExpr(String cronExpr) {
		this.cronExpr = cronExpr;
	}

	public String getFromHourOfDay() {
		return fromHourOfDay;
	}

	public void setFromHourOfDay(String fromHourOfDay) {
		this.fromHourOfDay = fromHourOfDay;
	}

	public String getToHourOfDay() {
		return toHourOfDay;
	}

	public void setToHourOfDay(String toHourOfDay) {
		this.toHourOfDay = toHourOfDay;
	}

	public String getIntervalMinute() {
		return intervalMinute;
	}

	public void setIntervalMinute(String intervalMinute) {
		this.intervalMinute = intervalMinute;
	}

	public long getTimeout() {
		return timeout;
	}

	public void setTimeout(long timeout) {
		this.timeout = timeout;
	}

	public int getConnectCount() {
		return connectCount;
	}

	public void setConnectCount(int connectCount) {
		this.connectCount = connectCount;
	}

	public boolean isMonitorState() {
		return monitorState;
	}

	public void setMonitorState(boolean monitorState) {
		this.monitorState = monitorState;
	}

	@Override
	public String getJobKeyName() {
		return this.getId() + "";
	}

	@Override
	public String getJobKeyGroup() {
		return this.getBusiSysId() + "";
	}

	@Override
	public String getDescription() {
		return this.getDeviceName();
	}
	
}
