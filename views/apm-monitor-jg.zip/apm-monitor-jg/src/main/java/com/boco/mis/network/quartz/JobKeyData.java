package com.boco.mis.network.quartz;

public interface JobKeyData {

	String getJobKeyName();
	
	String getJobKeyGroup();
	
	String getCronExpr();
	
	String getDescription();
}
