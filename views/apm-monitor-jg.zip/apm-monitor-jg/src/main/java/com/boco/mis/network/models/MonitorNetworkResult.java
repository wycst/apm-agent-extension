package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;

/**
 * 
 * @author wangyunchao
 *
 * 2018年9月3日 下午5:31:31
 */
@Table(name="monitor_network_result")
public class MonitorNetworkResult {

	@Id
	@Column
	private long id;
	
	// 关联网址地址id
	@Column(name="network_id")
	private int networkId;
	
	@Column(name="busi_sys_id")
	private int busiSysId;
	
	// 网络地址
	@Column
	private String url;
	
	// 开始时间     格式 yyyy-MM-dd HH:mm:ss.SSS  保留毫秒数
	@Column(name="begin_time")
	private String beginTime;
	
	// 结束时间     格式 yyyy-MM-dd HH:mm:ss.SSS
	@Column(name="end_time")
	private String endTime;
	
	// 开始毫秒数
	@Column(name="begin_mills")
	private long beginMills;
	
	// 结束毫秒数
	@Column(name="end_mills")
	private long endMills;
	
	// 耗时数
	@Column(name="time_mills")
	private long timeMills;
	
	@Column
	private int month;
	
	@Column
	private int day;
	
	// 当前参考最大超时毫秒
	@Column(name="standard_timeout")
	private long standardTimeout;
	
	// 是否可用（可连通）
	// 超时时间范围内返回了成功的状态码=200算可连通，其他
	@Column
	private boolean available;
	
	// 返回状态码
	@Column(name="res_code")
	private int resCode = -1;
	
	// 错误文本信息
	@Column(name="error_text")
	private String errorText;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getNetworkId() {
		return networkId;
	}

	public void setNetworkId(int networkId) {
		this.networkId = networkId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = beginTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public long getBeginMills() {
		return beginMills;
	}

	public void setBeginMills(long beginMills) {
		this.beginMills = beginMills;
	}

	public long getEndMills() {
		return endMills;
	}

	public void setEndMills(long endMills) {
		this.endMills = endMills;
	}

	public long getTimeMills() {
		return timeMills;
	}

	public void setTimeMills(long timeMills) {
		this.timeMills = timeMills;
	}

	public long getStandardTimeout() {
		return standardTimeout;
	}

	public void setStandardTimeout(long standardTimeout) {
		this.standardTimeout = standardTimeout;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public int getResCode() {
		return resCode;
	}

	public void setResCode(int resCode) {
		this.resCode = resCode;
	}

	public String getErrorText() {
		return errorText;
	}

	public void setErrorText(String errorText) {
		this.errorText = errorText;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getBusiSysId() {
		return busiSysId;
	}

	public void setBusiSysId(int busiSysId) {
		this.busiSysId = busiSysId;
	}
	
	
	
}
