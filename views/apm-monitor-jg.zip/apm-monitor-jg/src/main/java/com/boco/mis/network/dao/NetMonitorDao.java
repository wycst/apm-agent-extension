package com.boco.mis.network.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.stereotype.Repository;

import com.boco.mis.network.jdbc.dao.BaseJdbcDao;
import com.boco.mis.network.jdbc.db.DBManager;
@Repository
public class NetMonitorDao extends BaseJdbcDao {

	public Connection getConnection(boolean transaction) throws SQLException {
		return DBManager.getConnection();
	}

}
