package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;
/**
 * 区域表
 * @author wangyunchao
 *
 * 2018年9月26日 上午10:18:48
 */
@Table(name="monitor_region")
public class MonitorRegion {

	@Id
	@Column
	private int id;
	
	@Column(name="region_name")
	private String regionName;
	
	@Column(name="region_code")
	private String regionCode;
	
	@Column(name="region_desc")
	private String regionDesc;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public String getRegionCode() {
		return regionCode;
	}

	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	public String getRegionDesc() {
		return regionDesc;
	}

	public void setRegionDesc(String regionDesc) {
		this.regionDesc = regionDesc;
	}
	
}
