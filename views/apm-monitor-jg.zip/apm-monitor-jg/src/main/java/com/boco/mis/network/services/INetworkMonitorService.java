package com.boco.mis.network.services;

public interface INetworkMonitorService {

}
