package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;

@Table(name="monitor_database_result")
public class MonitorDatabaseResult {
	
	@Id
	@Column
	private int id;
	
	@Column(name = "database_id")
	private int databaseId ;
	
	@Column(name="busi_sys_id")
	private int busiSysId;

	@Column(name="database_url")
	private String databaseUrl;
	
	@Column(name="query_sql_returnval")
	private String querySqlReturnval;
	
	@Column(name="validate_expr")
	private String validateExpr;
	
	@Column
	private int validate;
	
	// 开始时间     格式 yyyy-MM-dd HH:mm:ss.SSS  保留毫秒数
	@Column(name="begin_time")
	private String beginTime;
	
	// 结束时间     格式 yyyy-MM-dd HH:mm:ss.SSS
	@Column(name="end_time")
	private String endTime;
	
	// 开始毫秒数
	@Column(name="begin_mills")
	private long beginMills;
	
	// 结束毫秒数
	@Column(name="end_mills")
	private long endMills;
	
	// 耗时数
	@Column(name="time_mills")
	private long timeMills;
	
	@Column
	private int month;
	
	@Column
	private int day;
	
	// 是否可用（可连通）
	@Column
	private boolean available;
	
	// 错误文本信息
	@Column(name="error_text")
	private String errorText;
}
