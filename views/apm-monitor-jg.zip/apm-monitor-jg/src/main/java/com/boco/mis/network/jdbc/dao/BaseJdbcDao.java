package com.boco.mis.network.jdbc.dao;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;


public abstract class BaseJdbcDao  {

	private Logger logger = Logger.getLogger(BaseJdbcDao.class);

	public List<Map<String, Object>> queryForMapList(String sql) {

		List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnection(false);
			ps = conn.prepareStatement(sql);
			logger.info(" sql = " + sql);
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			while (rs.next()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
				for (int i = 0; i < columnCount; i++) {
					String fieldName = rsmd.getColumnLabel(i + 1);
					int columnType = rsmd.getColumnType(i + 1);
					if (columnType == 91) {
						// 91 代表日期类型的
						rowData.put(fieldName, rs.getTimestamp(fieldName));
					} else if(columnType == Types.INTEGER || columnType == Types.BIGINT) {
						rowData.put(fieldName, rs.getLong(fieldName));
					} else {
						rowData.put(fieldName, rs.getString(fieldName));
					}
				}
				mapList.add(rowData);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return mapList;
	}

	public abstract Connection getConnection(boolean transaction) throws SQLException;

	public Map<String, Object> queryForMap(String sql) {

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = getConnection(false);
			ps = conn.prepareStatement(sql);
			logger.info(" sql = " + sql);
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			if (rs.next()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
				for (int i = 0; i < columnCount; i++) {
					String fieldName = rsmd.getColumnLabel(i + 1);
					int columnType = rsmd.getColumnType(i + 1);
					if (columnType == 91) {
						// 91 代表日期类型的
						rowData.put(fieldName, rs.getTimestamp(fieldName));
					} else {
						rowData.put(fieldName, rs.getString(fieldName));
					}
				}
				return rowData;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * 更新
	 * 
	 * @param sql
	 * @param params
	 * @return
	 */
	public int exexuteUpdate(String sql, Object... params) {

		Connection conn = null;
		PreparedStatement ps = null;

		try {
			conn = getConnection(true);
			ps = conn.prepareStatement(sql);
			logger.info(" sql = " + sql);
			int index = 1;
			for (Object param : params) {
				ps.setObject(index++, param);
			}
			return ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 原始sql插入记录，并返回主键
	 * 
	 * @param sql
	 * @param returnPk
	 *            是否返回主键
	 * @param params
	 * @return
	 */
	public Serializable executeInsert(String sql, boolean returnPk,
			Object... params) {
		Connection conn = null;
		PreparedStatement ps = null;
		Serializable s = 0;
		try {
			conn = getConnection(true);
			ps = conn.prepareStatement(sql);
			logger.info(" sql = " + sql);
			logger.info(" params = " + params);
			int index = 1;
			for (Object param : params) {
				ps.setObject(index++, param);
			}
			ps.executeUpdate();
			if (returnPk) {
				// 如果需要返回主键
				ps = conn.prepareStatement("select last_insert_id() as id ");
				ResultSet rs = ps.executeQuery();
				if (rs.next()) {
					s = rs.getInt("id");
				}
			}
			return s;

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage(), e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void insertModel(Connection conn,Object obj,boolean autoCommit) throws Exception {
		
		if (obj == null) {
			return;
		}
		Class<?> model = obj.getClass();

		Table table = (Table) model.getAnnotation(Table.class);
		String schame = table.schame();
		String tableName = table.name();
        if(tableName.length() == 0) {
        	tableName = model.getSimpleName();
        }
        String fullTableName = schame.length() == 0 ? tableName : schame + "." + tableName;
        
		Field[] fields = model.getDeclaredFields();
		List<Object> columnValueList = new ArrayList<Object>();

		Field idField = null;
		StringBuffer columnNames = new StringBuffer();
		StringBuffer valueOptions = new StringBuffer();
		try {
			for (Field field : fields) {
				field.setAccessible(true);
				Column column = field.getAnnotation(Column.class);
				if(column == null) continue;
				String fieldName = field.getName();
				String columnName = column.name();
				if(columnName.length() == 0) {
					columnName = fieldName;
				}
				String fieldName4GetMethod = fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
				
				String getMethodPrefix = "get";
				
				if(boolean.class == field.getType()) {
					getMethodPrefix = "is";
				}
				
				Method fieldGetMethod = model.getDeclaredMethod(getMethodPrefix + fieldName4GetMethod);
				Object columnValue = fieldGetMethod.invoke(obj);
				
				Id id = field.getAnnotation(Id.class);
				if (id != null) {
					// 自增主键不插入值
					idField = field;
					continue;
				}
				columnNames.append(columnName + ",");
				valueOptions.append("?,");
				columnValueList.add(columnValue);
			}

			if (columnNames.length() == 0) {
				return;
			}
			columnNames.deleteCharAt(columnNames.lastIndexOf(","));
			valueOptions.deleteCharAt(valueOptions.lastIndexOf(","));

			String sql = "insert into " + fullTableName + "(" + columnNames
					+ ") values(" + valueOptions + ")";

			PreparedStatement ps = null;
			try {
				if(!autoCommit) {
					conn.setAutoCommit(false);
				}
				if (idField != null) {
					ps = conn.prepareStatement(sql,
							Statement.RETURN_GENERATED_KEYS);
				} else {
					ps = conn.prepareStatement(sql);
				}
				logger.info(" sql = " + sql);
				logger.info(" columnValues = " + columnValueList.toArray());
				int index = 1;
				for (Object param : columnValueList) {
					ps.setObject(index++, param);
				}
				ps.executeUpdate();
				if (idField != null) {
					ResultSet rs = ps.getGeneratedKeys();
					if (rs.next()) {
						int id = rs.getInt(1);
						idField.set(obj, id);
					}
					if(rs != null) {
						rs.close();
					}
				}
			} catch (SQLException e) {
				throw e;
			} finally {
				if (ps != null) {
					try {
						ps.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if(autoCommit) {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void insertModel(Object obj,boolean autoCommit) throws Exception {
		insertModel(getConnection(autoCommit), obj, autoCommit);
	}
	
	/**
	 * 根据对象插入
	 * 
	 * @param obj
	 * @param returnPk
	 * @return
	 */
	public void insertModel(Object obj) throws Exception {
		insertModel(obj, true);
	}
	

}
