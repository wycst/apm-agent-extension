package com.boco.mis.network.controllers;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.boco.mis.network.models.MonitorBusiSys;
import com.boco.mis.network.models.MonitorDatabaseinfo;
import com.boco.mis.network.models.MonitorNetworkinfo;
import com.boco.mis.network.models.MonitorPinginfo;
import com.boco.mis.network.models.MonitorTcpinfo;
import com.boco.mis.network.services.impls.NetworkMonitorServiceImpl;

@Controller
@RequestMapping("monitor")
public class MonitorConfController {
	
	@Resource
	private NetworkMonitorServiceImpl networkMonitorService;
	
	/**
	 * 业务系统维护界面
	 */
	@RequestMapping(value = "/tree",produces={"text/html;charset=UTF-8;"})
	@ResponseBody
	public String tree() {
		List<Map<String, Object>> tree = networkMonitorService.getTreeData(null);
		String treeJson = JSON.toJSONString(tree);
		return treeJson;
	}
	
	/**
	 * 业务系统维护界面
	 */
	@RequestMapping(value = "/conf")
	public String networkinfo(HttpServletRequest request) {
		
		List<Map<String, Object>> regionList = networkMonitorService.queryRegions();
		request.setAttribute("regionList", regionList);
		
		// busiSysList
		List<Map<String, Object>> busiSysList = networkMonitorService.queryBusiSys(null);
		request.setAttribute("busiSysList", busiSysList);
		
		// 代理服务器列表
//		List<Map<String, Object>> proxyList = networkMonitorService.queryProxys();
//		request.setAttribute("proxyList", proxyList);
		
		return "monitor-conf";
	}
	
	/**
	 * 
	 */
	@RequestMapping(value = "/saveNetwork", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
	@ResponseBody
	public String saveNetwork(@RequestBody String networkInfoConent) {
		try {
			MonitorNetworkinfo info = JSONObject.parseObject(networkInfoConent,MonitorNetworkinfo.class);
			networkMonitorService.saveOrUpdate(info);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 
	 */
	@RequestMapping(value = "/saveSys", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
	@ResponseBody
	public String saveSys(@RequestBody String busiSysConent) {
		try {
			MonitorBusiSys busiSys = JSONObject.parseObject(busiSysConent,MonitorBusiSys.class);
			networkMonitorService.saveOrUpdateBusiSys(busiSys);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 删除http
	 */
	@RequestMapping(value = "/deleteNetwork")
	@ResponseBody
	public String deleteNetwork(int id) {
		try {
			networkMonitorService.deleteNetwork(id);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 保存tcp
	 */
	@RequestMapping(value = "/saveTcp", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
	@ResponseBody
	public String saveTcp(@RequestBody String tcpInfoConent) {
		try {
			MonitorTcpinfo info = JSONObject.parseObject(tcpInfoConent,MonitorTcpinfo.class);
			networkMonitorService.saveOrUpdateMonitorTcpinfo(info);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 删除tcp
	 */
	@RequestMapping(value = "/deleteTcp")
	@ResponseBody
	public String deleteTcp(int id) {
		try {
			networkMonitorService.deleteTcp(id);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 保存数据库信息
	 */
	@RequestMapping(value = "/saveDatabase", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
	@ResponseBody
	public String saveDatabase(@RequestBody String databaseInfoConent) {
		try {
			MonitorDatabaseinfo info = JSONObject.parseObject(databaseInfoConent,MonitorDatabaseinfo.class);
			networkMonitorService.saveOrUpdateMonitorDatabaseinfo(info);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 删除数据库信息
	 */
	@RequestMapping(value = "/deleteDatabase")
	@ResponseBody
	public String deleteDatabase(int id) {
		try {
			networkMonitorService.deleteDatabase(id);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	

	/**
	 * 保存ping信息
	 */
	@RequestMapping(value = "/savePing", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
	@ResponseBody
	public String savePing(@RequestBody String pingInfoConent) {
		try {
			MonitorPinginfo info = JSONObject.parseObject(pingInfoConent,MonitorPinginfo.class);
			networkMonitorService.saveOrUpdateMonitorPinginfo(info);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	/**
	 * 删除ping信息
	 */
	@RequestMapping(value = "/deletePing")
	@ResponseBody
	public String deletePing(int id) {
		try {
			networkMonitorService.deletePing(id);
			return "success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
	}
	
	
	
	
	
	
}
