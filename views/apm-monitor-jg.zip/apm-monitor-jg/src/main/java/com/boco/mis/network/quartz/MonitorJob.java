package com.boco.mis.network.quartz;

import java.util.Date;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.boco.mis.network.models.MonitorDatabaseinfo;
import com.boco.mis.network.models.MonitorNetworkinfo;
import com.boco.mis.network.models.MonitorPinginfo;
import com.boco.mis.network.models.MonitorTcpinfo;
import com.boco.mis.network.monitor.MonitorDatabaseHandler;
import com.boco.mis.network.monitor.MonitorPinginfoHandler;
import com.boco.mis.network.monitor.MonitorTcpHandler;
import com.boco.mis.network.monitor.NetworkMonitorHandler;

public class MonitorJob implements Job {

	private Logger logger = Logger.getLogger(MonitorJob.class);
	
	public void execute(JobExecutionContext arg0) throws JobExecutionException {

		JobDataMap dataMap = arg0.getJobDetail().getJobDataMap();
		JobKeyData data = (JobKeyData) dataMap.get("data");
	
		logger.info(" fire time = " + arg0.getFireTime());
		logger.info(" current time = " + new Date());
		
		if(data instanceof MonitorNetworkinfo) {
			NetworkMonitorHandler.monitor((MonitorNetworkinfo) data);
		} else if(data instanceof MonitorTcpinfo) {
			MonitorTcpHandler.monitor((MonitorTcpinfo) data);
		} else if(data instanceof MonitorDatabaseinfo) {
			MonitorDatabaseHandler.monitor((MonitorDatabaseinfo) data);
		} else if(data instanceof MonitorPinginfo) {
			MonitorPinginfoHandler.monitor((MonitorPinginfo) data);
		} else {
			
		}
	}

}
