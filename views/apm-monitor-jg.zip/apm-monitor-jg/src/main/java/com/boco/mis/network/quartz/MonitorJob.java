package com.boco.mis.network.quartz;

import java.util.Date;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.boco.mis.network.models.MonitorNetworkinfo;
import com.boco.mis.network.monitor.NetworkMonitorHandler;

public class MonitorJob implements Job {

	private Logger logger = Logger.getLogger(MonitorJob.class);
	
	public void execute(JobExecutionContext arg0) throws JobExecutionException {

		JobDataMap dataMap = arg0.getJobDetail().getJobDataMap();
		JobKeyData data = (JobKeyData) dataMap.get("data");
	
		logger.info(" fire time = " + arg0.getFireTime());
		logger.info(" current time = " + new Date());
		MonitorNetworkinfo info = (MonitorNetworkinfo) data;
		NetworkMonitorHandler.monitor(info);
	}

}
