package com.boco.mis.network.jdbc.db;

import java.beans.PropertyVetoException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;

import com.boco.mis.network.jdbc.datasource.C3p0DataSourceInfo;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBManager implements Serializable {

	private static final long serialVersionUID = -1377140841549844097L;

	private static ComboPooledDataSource cpds;

	static {
		init();
	}

	private static void init() {
		cpds = new ComboPooledDataSource(true);
		cpds.setJdbcUrl(C3p0DataSourceInfo.getUrl());
		try {
			cpds.setDriverClass(C3p0DataSourceInfo.getDriverClass());
		} catch (PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cpds.setUser(C3p0DataSourceInfo.getUsername());
		cpds.setPassword(C3p0DataSourceInfo.getPassword());
		cpds.setMaxPoolSize(C3p0DataSourceInfo.getMaxPoolSize());
		cpds.setMinPoolSize(C3p0DataSourceInfo.getMinPoolSize());
		cpds.setAcquireIncrement(C3p0DataSourceInfo.getAcquireIncrement());
		cpds.setInitialPoolSize(C3p0DataSourceInfo.getInitialPoolSize());
		cpds.setMaxIdleTime(C3p0DataSourceInfo.getMaxIdleTime());
	}

	public static Connection getConnection() throws SQLException {
		return cpds.getConnection();
	}
}
