package com.boco.mis.network.models;

import com.boco.mis.network.jdbc.annotations.Column;
import com.boco.mis.network.jdbc.annotations.Id;
import com.boco.mis.network.jdbc.annotations.Table;

@Table(name="monitor_busi_sys")
public class MonitorBusiSys {

	// 业务系统id
	@Column
	@Id
	private int id;
	
	// 业务系统名称
	@Column(name="sys_name")
	private String sysName;
	
	// 业务系统编码
	@Column(name="sys_code")
	private String sysCode;
	
	// web页面名称
	@Column(name="web_page_name")
	private String webPageName;
	
	// 项目经理
	@Column
	private String manager;
	
	// 实施人员
	@Column(name="manufacturer")
	private String manufacturer;
	
	// 实施人员电话
	@Column(name="manufacturer_phone")
	private String manufacturerPhone;
	
	// 实施人员邮箱
	@Column(name="manufacturer_mail")
	private String manufacturerMail;

	// 所属区域id
	@Column(name="region_id")
	private int regionId;
	
	// 非持久化数据
    private String urls;
	
	private int priority;
	
	private String serverIp;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSysName() {
		return sysName;
	}

	public void setSysName(String sysName) {
		this.sysName = sysName;
	}

	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getManufacturerPhone() {
		return manufacturerPhone;
	}

	public void setManufacturerPhone(String manufacturerPhone) {
		this.manufacturerPhone = manufacturerPhone;
	}

	public String getManufacturerMail() {
		return manufacturerMail;
	}

	public void setManufacturerMail(String manufacturerMail) {
		this.manufacturerMail = manufacturerMail;
	}

	public String getWebPageName() {
		return webPageName;
	}

	public void setWebPageName(String webPageName) {
		this.webPageName = webPageName;
	}

	public int getRegionId() {
		return regionId;
	}

	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}

	public String getUrls() {
		return urls;
	}

	public void setUrls(String urls) {
		this.urls = urls;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}
	
}
