package com.boco.mis.network.services.impls;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.boco.mis.network.dao.NetMonitorDao;
import com.boco.mis.network.models.MonitorBusiSys;
import com.boco.mis.network.models.MonitorDatabaseinfo;
import com.boco.mis.network.models.MonitorNetworkinfo;
import com.boco.mis.network.models.MonitorPinginfo;
import com.boco.mis.network.models.MonitorTcpinfo;
import com.boco.mis.network.quartz.QuartzUtils;
import com.boco.mis.network.services.INetworkMonitorService;


@Service
public class NetworkMonitorServiceImpl implements INetworkMonitorService {

	private List<MonitorNetworkinfo> networks ;
	
	@Resource
	private NetMonitorDao netMonitorDao;
	
	static {
			
	}

	// 服务启动执行定时计划
	@PostConstruct
	public void startup() {
		monitor();
	}
	
	// 临时设置方案，正式从数据库读取
	public void monitor() {
		
		List<Map<String, Object>> netMaps = netMonitorDao.queryForMapList("select t.*,proxy.proxy_host,proxy.proxy_port from monitor_networkinfo t left join monitor_proxy proxy on t.proxy_id = proxy.id where t.monitor_state = 1 ");
		networks = JSONArray.parseArray(JSON.toJSONString(netMaps), MonitorNetworkinfo.class);
		if(networks != null) {
			for(MonitorNetworkinfo info : networks) {
				if(info.getCronExpr() != null && info.getCronExpr().length() > 0) {
					QuartzUtils.scheduleJob(info);
				} 
			}
		}
	}

	public void importBusiSysList(List<MonitorBusiSys> busiSysList) {
	
		if(networks == null) 
		networks = new ArrayList<MonitorNetworkinfo>();
		
		boolean importFlag = false;
		
		if(busiSysList != null) {
			Connection conn = null;
			try {
				conn = netMonitorDao.getConnection(true);
				conn.setAutoCommit(false);
				for(MonitorBusiSys busiSys : busiSysList) {
					String urls = busiSys.getUrls();
					netMonitorDao.insertModel(conn,busiSys, false);
					for(String url : urls.split(",")) {
						MonitorNetworkinfo networkInfo = new MonitorNetworkinfo();
						networkInfo.setBusiSys(busiSys);
						
						networkInfo.setUrl(url);
						networkInfo.setServerIp(busiSys.getServerIp());
						networkInfo.setPriority(busiSys.getPriority());
						networkInfo.setWebPageName(busiSys.getWebPageName());
						
						netMonitorDao.insertModel(conn,networkInfo, false);
						networks.add(networkInfo);
					}
				}
				conn.commit();
				
				importFlag = true;
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} finally {
				if(conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		if(importFlag) {
//			monitor();
		}
		
	}

	public List<Map<String, Object>> queryBusiSys(String sysName) {
		String sql = " select t.id,t.sys_name as sysName,t.web_page_name as webPageName,t.manager,t.manufacturer from monitor_busi_sys t where 1 = 1 ";
		if(sysName != null && sysName.length() > 0) {
			sql += " and t.sys_name like '%"+sysName+"%'";
		}
		List<Map<String, Object>> sysList = netMonitorDao.queryForMapList(sql);
		return sysList;
	}

	public List<Map<String, Object>> getTreeData(String regionCode) {
		
		// 暂时查询所有的区域
		String regionSql = "select mr.id,mr.region_name name from monitor_region mr where 1 = 1 ";
		if(regionCode != null) {
			regionSql += " and mr.region_code = '"+regionCode+"'";
		}
		List<Map<String, Object>> regionList = netMonitorDao.queryForMapList(regionSql);
		
		// 查询所有的业务系统
		String findSysSql = " select t.id, t.region_id regionId,t.sys_name as name,t.sys_name sysName,t.sys_code sysCode,t.manager,t.manufacturer,t.manufacturer_phone manufacturerPhone,t.manufacturer_mail manufacturerMail from monitor_busi_sys t ";
		List<Map<String, Object>> sysList = netMonitorDao.queryForMapList(findSysSql);
		
		// 区域与业务系统的关系树
		for(Map<String, Object> region : regionList) {
			String id = region.get("id").toString();
			List<Map<String, Object>> children = new ArrayList<Map<String, Object>>();
			for(Map<String, Object> sys : sysList) {
				String pid = sys.get("regionId").toString();
				if(id.equals(pid)) {
					children.add(sys);
				}
			}
			region.put("type", "region");
			region.put("children", children);
		}
		
		// 查询所有的网址
		String findNetworkInfoSql = " select t.id,t.web_page_name as name,t.busi_sys_id as pid,t.busi_sys_id busiSysId,t.web_page_name webPageName,t.server_ip serverIp, t.url,t.monitor_state monitorState,t.from_hour_of_day fromHourOfDay,t.to_hour_of_day toHourOfDay,t.interval_minute intervalMinute,t.timeout,t.connect_count connectCount,t.proxy_id proxyId from monitor_networkinfo t ";
		List<Map<String, Object>> networkList = netMonitorDao.queryForMapList(findNetworkInfoSql);
		
		// 查询tcp
		String findTcpInfoSql = " select t.id,t.device_name as name,t.busi_sys_id as pid,t.device_name deviceName,t.busi_sys_id busiSysId,t.tcp_host tcpHost,t.tcp_port tcpPort, t.monitor_state monitorState,t.from_hour_of_day fromHourOfDay,t.to_hour_of_day toHourOfDay,t.interval_minute intervalMinute,t.timeout,t.connect_count connectCount,t.proxy_id proxyId from monitor_tcpinfo t ";
		List<Map<String, Object>> tcpList = netMonitorDao.queryForMapList(findTcpInfoSql);
		
		// 查询database
		String findDatabaseInfoSql = " select t.id,t.device_name as name,t.busi_sys_id as pid,t.device_name deviceName,t.busi_sys_id busiSysId,t.database_url databaseUrl,t.database_type databaseType,t.database_user databaseUser,t.database_pwd databasePwd,t.query_sql querySql,t.validate_expr validateExpr, t.monitor_state monitorState,t.from_hour_of_day fromHourOfDay,t.to_hour_of_day toHourOfDay,t.interval_minute intervalMinute,t.timeout,t.connect_count connectCount,t.proxy_id proxyId from monitor_databaseinfo t ";
		List<Map<String, Object>> databaseList = netMonitorDao.queryForMapList(findDatabaseInfoSql);
		
		// 查询ping
		String findPingInfoSql = " select t.id,t.device_name as name,t.busi_sys_id as pid,t.device_name deviceName,t.busi_sys_id busiSysId,t.ping_ip pingIp,t.ping_packet_num pingPacketNum, t.monitor_state monitorState,t.from_hour_of_day fromHourOfDay,t.to_hour_of_day toHourOfDay,t.interval_minute intervalMinute,t.timeout,t.connect_count connectCount,t.proxy_id proxyId from monitor_pinginfo t ";
		List<Map<String, Object>> pingList = netMonitorDao.queryForMapList(findPingInfoSql);
		
		// 查询所有的tcp配置
		// 查询所有的database配置
		// 查询所有的ping配置
		for(Map<String, Object> busiSys : sysList) {
			String id = busiSys.get("id").toString();
			List<Map<String, Object>> children = new ArrayList<Map<String, Object>>();
			
			// 网络地址
			for(Map<String, Object> network : networkList) {
				String pid = network.get("pid").toString();
				if(id.equals(pid)) {
					network.put("type", "http");
					network.put("name", "[http]-" + network.get("name"));
					children.add(network);
				}
			}
			
			// tcp
			for(Map<String, Object> tcp : tcpList) {
				String pid = tcp.get("pid").toString();
				if(id.equals(pid)) {
					tcp.put("type", "tcp");
					tcp.put("name", "[tcp]-" + tcp.get("name"));
					children.add(tcp);
				}
			}
			
			// database
			for(Map<String, Object> database : databaseList) {
				String pid = database.get("pid").toString();
				if(id.equals(pid)) {
					database.put("type", "db");
					database.put("name", "[db]-" + database.get("name"));
					children.add(database);
				}
			}
			
			// ping
			for(Map<String, Object> ping : pingList) {
				String pid = ping.get("pid").toString();
				if(id.equals(pid)) {
					ping.put("type", "ping");
					ping.put("name", "[ping]-" + ping.get("name"));
					children.add(ping);
				}
			}
			
			busiSys.put("type", "busiSys");
			busiSys.put("children", children);
		}
		if(regionList.size() == 0) {
			return sysList;
		}
		return regionList;
	}

	public void saveOrUpdate(MonitorNetworkinfo info) {
		// "*/20 * 8-19 * * ?"
		int to = Integer.parseInt(info.getToHourOfDay());
		// 凌晨0点
		if(to <= 0 || to >= 24) to = 24;
		// 小时数－1
		String cronExpr = "0 */" + info.getIntervalMinute() + " " + info.getFromHourOfDay() + "-" + (to - 1) + " * * ?";
		info.setCronExpr(cronExpr);
		
		boolean saveState = true;
		if(info.getId() != 0) {
			String sql = " update monitor_networkinfo set url = ?,web_page_name = ?,server_ip = ?, monitor_state = ?,from_hour_of_day = ? ,to_hour_of_day = ? ,interval_minute = ? ,timeout = ? ,connect_count = ?,cron_expr = ?,proxy_id = ? where id = ? ";
			netMonitorDao.exexuteUpdate(sql, info.getUrl(),info.getWebPageName(),info.getServerIp(),info.isMonitorState(),info.getFromHourOfDay(),info.getToHourOfDay(),info.getIntervalMinute(),info.getTimeout(),info.getConnectCount(),cronExpr,info.getProxyId(),info.getId());
		} else {
			try {
				netMonitorDao.insertModel(info);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				saveState = false;
			}
		}
		if(saveState) {
			if(!info.isMonitorState()) {
				QuartzUtils.stopQuartzTimer(info);
			} else {
				QuartzUtils.startQuartzTimer(info);
			}
		}
	}
	
	public void saveOrUpdateMonitorTcpinfo(MonitorTcpinfo info) {
		// "*/20 * 8-19 * * ?"
		int to = Integer.parseInt(info.getToHourOfDay());
		// 凌晨0点
		if(to <= 0 || to >= 24) to = 24;
		// 小时数－1
		String cronExpr = "0 */" + info.getIntervalMinute() + " " + info.getFromHourOfDay() + "-" + (to - 1) + " * * ?";
		info.setCronExpr(cronExpr);
		
		boolean saveState = true;
		if(info.getId() != 0) {
			String sql = " update monitor_tcpinfo set tcp_host = ?,device_name = ?,tcp_port = ?, monitor_state = ?,from_hour_of_day = ? ,to_hour_of_day = ? ,interval_minute = ? ,timeout = ? ,connect_count = ?,cron_expr = ?,proxy_id = ? where id = ? ";
			netMonitorDao.exexuteUpdate(sql, info.getTcpHost(),info.getDeviceName(),info.getTcpPort(),info.isMonitorState(),info.getFromHourOfDay(),info.getToHourOfDay(),info.getIntervalMinute(),info.getTimeout(),info.getConnectCount(),cronExpr,info.getProxyId(),info.getId());
		} else {
			try {
				netMonitorDao.insertModel(info);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				saveState = false;
			}
		}
//		if(saveState) {
//			if(!info.isMonitorState()) {
//				QuartzUtils.stopQuartzTimer(info);
//			} else {
//				QuartzUtils.startQuartzTimer(info);
//			}
//		}
	}
	

	public void saveOrUpdateBusiSys(MonitorBusiSys busiSys) {
		if(busiSys.getId() == 0) {
			try {
				netMonitorDao.insertModel(busiSys);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			String sql = " update monitor_busi_sys set region_id = ?, sys_name = ?,sys_code = ? ,manager = ?,manufacturer = ? ,manufacturer_phone = ? ,manufacturer_mail = ?  where id = ? ";
			netMonitorDao.exexuteUpdate(sql,busiSys.getRegionId(), busiSys.getSysName(),busiSys.getSysCode(),busiSys.getManager(),busiSys.getManufacturer(),busiSys.getManufacturerPhone(),busiSys.getManufacturerMail(),busiSys.getId());
		}
	}

	public void deleteNetwork(int id) {
		
		Map<String,Object> networkMap = netMonitorDao.queryForMap(" select busi_sys_id busiSysId,id from monitor_networkinfo where id = " + id);
		MonitorNetworkinfo info = new MonitorNetworkinfo();
		info.setBusiSysId(Integer.parseInt(networkMap.get("busiSysId") + ""));
		info.setId(Integer.parseInt(networkMap.get("id") + ""));
		
		netMonitorDao.exexuteUpdate(" delete from monitor_networkinfo where id = ?", id);
		
		// 停掉定时器
		QuartzUtils.stopQuartzTimer(info);
	}

	public List<Map<String, Object>> queryProxys() {
		List<Map<String,Object>> proxys = netMonitorDao.queryForMapList(" select id,name,proxy_host host,proxy_port port from monitor_proxy ");
		return proxys;
	}

	public List<Map<String, Object>> queryRegions() {
		List<Map<String,Object>> regions = netMonitorDao.queryForMapList("select mr.id,mr.region_name regionName from monitor_region mr ");
		return regions;
	}

	public void deleteTcp(int id) {
		Map<String,Object> tcpMap = netMonitorDao.queryForMap(" select busi_sys_id busiSysId,id from monitor_tcpinfo where id = " + id);
		MonitorTcpinfo info = new MonitorTcpinfo();
		info.setBusiSysId(Integer.parseInt(tcpMap.get("busiSysId") + ""));
		info.setId(Integer.parseInt(tcpMap.get("id") + ""));
		netMonitorDao.exexuteUpdate(" delete from monitor_tcpinfo where id = ?", id);
		// 停掉定时器
		QuartzUtils.stopQuartzTimer(info);
	}
	
	public void saveOrUpdateMonitorDatabaseinfo(MonitorDatabaseinfo info) {
		// "*/20 * 8-19 * * ?"
		int to = Integer.parseInt(info.getToHourOfDay());
		// 凌晨0点
		if(to <= 0 || to >= 24) to = 24;
		// 小时数－1
		String cronExpr = "0 */" + info.getIntervalMinute() + " " + info.getFromHourOfDay() + "-" + (to - 1) + " * * ?";
		info.setCronExpr(cronExpr);
		
		// validate_expr
		boolean saveState = true;
		if(info.getId() != 0) {
			String sql = " update monitor_databaseinfo set database_url = ?,device_name = ?,database_user = ?,database_pwd = ?,database_type = ?,query_sql = ?,validate_expr = ?, monitor_state = ?,from_hour_of_day = ? ,to_hour_of_day = ? ,interval_minute = ? ,timeout = ? ,connect_count = ?,cron_expr = ?,proxy_id = ? where id = ? ";
			netMonitorDao.exexuteUpdate(sql, info.getDatabaseUrl(),info.getDeviceName(),info.getDatabaseUser(),info.getDatabasePwd(),info.getDatabaseType(),info.getQuerySql(),info.getValidateExpr(),info.isMonitorState(),info.getFromHourOfDay(),info.getToHourOfDay(),info.getIntervalMinute(),info.getTimeout(),info.getConnectCount(),cronExpr,info.getProxyId(),info.getId());
		} else {
			try {
				netMonitorDao.insertModel(info);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				saveState = false;
			}
		}
		if(saveState) {
			if(!info.isMonitorState()) {
				QuartzUtils.stopQuartzTimer(info);
			} else {
				QuartzUtils.startQuartzTimer(info);
			}
		}
	}

	public void deleteDatabase(int id) {
		Map<String,Object> dataMap = netMonitorDao.queryForMap(" select busi_sys_id busiSysId,id from monitor_databaseinfo where id = " + id);
		MonitorTcpinfo info = new MonitorTcpinfo();
		info.setBusiSysId(Integer.parseInt(dataMap.get("busiSysId") + ""));
		info.setId(Integer.parseInt(dataMap.get("id") + ""));
		netMonitorDao.exexuteUpdate(" delete from monitor_databaseinfo where id = ?", id);
		// 停掉定时器
		QuartzUtils.stopQuartzTimer(info);
	}

	public void saveOrUpdateMonitorPinginfo(MonitorPinginfo info) {
		// "*/20 * 8-19 * * ?"
				int to = Integer.parseInt(info.getToHourOfDay());
				// 凌晨0点
				if(to <= 0 || to >= 24) to = 24;
				// 小时数－1
				String cronExpr = "0 */" + info.getIntervalMinute() + " " + info.getFromHourOfDay() + "-" + (to - 1) + " * * ?";
				info.setCronExpr(cronExpr);
				
				// validate_expr
				boolean saveState = true;
				if(info.getId() != 0) {
					String sql = " update monitor_pinginfo set ping_ip = ?,device_name = ?,ping_packet_num = ?, monitor_state = ?,from_hour_of_day = ? ,to_hour_of_day = ? ,interval_minute = ? ,timeout = ? ,connect_count = ?,cron_expr = ?,proxy_id = ? where id = ? ";
					netMonitorDao.exexuteUpdate(sql, info.getPingIp(),info.getDeviceName(),info.getPingPacketNum(),info.isMonitorState(),info.getFromHourOfDay(),info.getToHourOfDay(),info.getIntervalMinute(),info.getTimeout(),info.getConnectCount(),cronExpr,info.getProxyId(),info.getId());
				} else {
					try {
						netMonitorDao.insertModel(info);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						saveState = false;
					}
				}
				if(saveState) {
					if(!info.isMonitorState()) {
						QuartzUtils.stopQuartzTimer(info);
					} else {
						QuartzUtils.startQuartzTimer(info);
					}
				}
	}

	public void deletePing(int id) {
		Map<String,Object> dataMap = netMonitorDao.queryForMap(" select busi_sys_id busiSysId,id from monitor_pinginfo where id = " + id);
		MonitorPinginfo info = new MonitorPinginfo();
		info.setBusiSysId(Integer.parseInt(dataMap.get("busiSysId") + ""));
		info.setId(Integer.parseInt(dataMap.get("id") + ""));
		netMonitorDao.exexuteUpdate(" delete from monitor_pinginfo where id = ?", id);
		// 停掉定时器
		QuartzUtils.stopQuartzTimer(info);
	}

	
}
