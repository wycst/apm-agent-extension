package com.boco.mis.network.jdbc.annotations;

@java.lang.annotation.Target(value = { java.lang.annotation.ElementType.FIELD })
@java.lang.annotation.Retention(value = java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface Column {

	String name() default "";
	
}
