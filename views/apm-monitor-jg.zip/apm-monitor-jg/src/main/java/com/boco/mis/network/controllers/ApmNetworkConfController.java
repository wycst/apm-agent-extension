package com.boco.mis.network.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.boco.mis.network.models.MonitorBusiSys;
import com.boco.mis.network.models.MonitorNetworkinfo;
import com.boco.mis.network.services.impls.NetworkMonitorServiceImpl;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("network")
public class ApmNetworkConfController {
	
	private static final Logger logger = LoggerFactory.getLogger(ApmNetworkConfController.class);
	private static final org.apache.log4j.Logger logger4j = org.apache.log4j.Logger.getLogger(ApmNetworkConfController.class);
	
	@Resource
	private NetworkMonitorServiceImpl networkMonitorService;
	
//	/**
//	 * home
//	 */
//	@RequestMapping(value = "/index")
//	public String index() {
//		return "import";
//	}
//	
//	/**
//	 * 
//	 */
//	@RequestMapping(value = "/import", method = RequestMethod.POST,produces = {"application/x-www-form-urlencoded"})
//	public String networkImp(@RequestBody String networkContents) {
//		System.out.println(networkContents);
//		List<MonitorBusiSys> busiSysList = JSONArray.parseArray(networkContents, MonitorBusiSys.class);
////		networkMonitorService.setStaticNetworks(networks);
//		networkMonitorService.importBusiSysList(busiSysList);
//		return "import";
//	}
//	
	
//	/**
//	 * 
//	 */
//	@RequestMapping(value = "/monitor")
//	public String monitor() {
//		networkMonitorService.monitor();
//		return "import";
//	}
	
//	/**
//	 * 业务系统维护界面
//	 */
//	@RequestMapping(value = "/busiSys")
//	public String busiSys() {
//		return "busiSys";
//	}
//	
//	/**
//	 * 业务系统维护界面
//	 */
//	@RequestMapping(value = "/queryBusiSys",produces={"text/html;charset=UTF-8;"})
//	@ResponseBody
//	public String queryBusiSys(String sysName,Integer page,Integer limit,HttpServletResponse response) {
//		
//		response.setCharacterEncoding("utf-8");
//		response.setContentType("text/html;charset=utf-8");
//		
//		List<Map<String, Object>> busiSysList = networkMonitorService.queryBusiSys(sysName);
//		
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("code", 0);
//		int count = busiSysList.size();
//		int fromIndex = (page - 1) * limit;
//	    int toIndex = page * limit;
//		
//	    if(toIndex > count) {
//	    	toIndex = count;
//	    }
//		map.put("data", busiSysList.subList(fromIndex, toIndex));
//		map.put("count", count);
//		
//		String sysJson = JSON.toJSONString(map);
//		System.out.println(sysJson);
//		return sysJson;
//	}
//	
	
//	/**
//	 * 业务系统维护界面
//	 */
//	@RequestMapping(value = "/networkinfo")
//	public String networkinfo(HttpServletRequest request) {
//		
//		// busiSysList
//		List<Map<String, Object>> busiSysList = networkMonitorService.queryBusiSys(null);
//		request.setAttribute("busiSysList", busiSysList);
//		
//		// 代理服务器列表
//		List<Map<String, Object>> proxyList = networkMonitorService.queryProxys();
//		request.setAttribute("proxyList", proxyList);
//		
//		return "networkinfo";
//	}
	
	
}
