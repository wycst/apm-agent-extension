package com.boco.mis.network.sys;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class MonitorPropertiesConf {
	
	private static final Logger logger = LoggerFactory.getLogger(MonitorPropertiesConf.class);
	
	static Properties properties = new Properties();
	static {
		try {
			InputStream is = MonitorPropertiesConf.class.getResourceAsStream("/monitor.properties");
			properties.load(is);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		httpProxySetting();
	}
	
	private static void httpProxySetting() {
//		logger.info(" httpProxySetting ");
//		String proxyHost = properties.getProperty("monitor.http.ProxyHost");
//		String proxyPort = properties.getProperty("monitor.http.ProxyPort");
//		if(proxyHost != null && !proxyHost.equals("-1")) {
//			System.setProperty("http.proxyHost", proxyHost);
//			System.setProperty("https.proxyHost", proxyHost);
//			logger.info(" init httpProxy host" + proxyHost);
//		}
//		if(proxyPort != null && !proxyPort.equals("-1")) {
//			System.setProperty("http.proxyPort", proxyPort);
//			System.setProperty("https.proxyPort", proxyPort);
//			logger.info(" init httpProxy Port" + proxyPort);
//		}
//		
//		System.out.println("====== http.proxyHost " + System.getProperty("http.proxyHost"));
//		System.out.println("====== http.proxyPort " + System.getProperty("http.proxyPort"));
//		
		
	}
	
	/**
	 * 获取区域配置
	 * @return
	 */
	public static String getRegion() {
		return properties.getProperty("monitor.region");
	}
	
}
